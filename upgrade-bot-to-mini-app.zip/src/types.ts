export interface User {
  id: number;
  username: string;
  firstName: string;
  balance: number;
  totalDeposit: number;
  totalWithdraw: number;
  totalWon: number;
  totalLost: number;
  gamesPlayed: number;
  vipLevel: number;
  dailyBonusDate: string;
  joinDate: string;
  referralCode: string;
  referredBy: string | null;
  referralCount: number;
  referralEarnings: number;
}

export interface GameSession {
  id: number;
  gameType: string;
  betAmount: number;
  result: 'win' | 'lose' | 'draw';
  profitLoss: number;
  date: string;
}

export interface BigWin {
  username: string;
  gameType: string;
  amount: number;
  date: string;
}

export type GameType = 'rps' | 'slot' | 'guess' | 'dice' | 'crash';
export type Screen = 'main' | 'games' | 'game_rps' | 'game_slot' | 'game_guess' | 'game_dice' | 'game_crash' | 'wallet' | 'stats' | 'vip' | 'referral' | 'leaderboard';
