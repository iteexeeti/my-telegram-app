import { useState, useEffect } from 'react';
import { User, Screen } from './types';
import { getUser, saveUser, getBigWins, updateVIP } from './store';
import GameRPS from './components/GameRPS';
import GameSlot from './components/GameSlot';
import GameGuess from './components/GameGuess';
import GameDice from './components/GameDice';
import GameCrash from './components/GameCrash';
import Referral from './components/Referral';
import Wallet from './components/Wallet';

const DAILY_BONUS = 2000;
const VIP_BONUS_MULT: Record<number, number> = { 1: 1.0, 2: 1.05, 3: 1.10, 4: 1.15, 5: 1.20 };
const VIP_NAMES: Record<number, string> = { 1: '🥉 برنز', 2: '🥈 نقره', 3: '🥇 طلا', 4: '💎 الماس', 5: '👑 VIP' };

export function App() {
  const [user, setUser] = useState<User | null>(null);
  const [screen, setScreen] = useState<Screen>('main');
  const [tab, setTab] = useState<'games' | 'wallet' | 'stats' | 'more'>('games');
  const [bonusMsg, setBonusMsg] = useState('');
  const [showBonusModal, setShowBonusModal] = useState(false);

  useEffect(() => {
    const tg = (window as any).Telegram?.WebApp;
    if (tg) {
      tg.ready();
      tg.expand();
      tg.setHeaderColor('#111827');
    }
    const u = getUser();
    updateVIP(u);
    saveUser(u);
    setUser(u);
  }, []);

  function updateUser(u: User) {
    updateVIP(u);
    saveUser(u);
    setUser({ ...u });
  }

  function claimDailyBonus() {
    if (!user) return;
    const today = new Date().toISOString().split('T')[0];
    if (user.dailyBonusDate === today) {
      setBonusMsg('⏰ بونوس روزانه قبلاً دریافت شده! فردا دوباره بیایید.');
      setShowBonusModal(true);
      return;
    }
    const mult = VIP_BONUS_MULT[user.vipLevel] || 1.0;
    const bonus = Math.floor(DAILY_BONUS * mult);
    const updated = { ...user, balance: user.balance + bonus, dailyBonusDate: today };
    updateUser(updated);
    setBonusMsg(`🎁 ${bonus.toLocaleString()} 🪙 بونوس روزانه دریافت شد!`);
    setShowBonusModal(true);
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="text-white text-xl animate-pulse">🎰 در حال بارگذاری...</div>
      </div>
    );
  }

  // Sub-screens
  if (screen === 'game_rps') return <GameRPS user={user} onUserUpdate={updateUser} onBack={() => setScreen('main')} />;
  if (screen === 'game_slot') return <GameSlot user={user} onUserUpdate={updateUser} onBack={() => setScreen('main')} />;
  if (screen === 'game_guess') return <GameGuess user={user} onUserUpdate={updateUser} onBack={() => setScreen('main')} />;
  if (screen === 'game_dice') return <GameDice user={user} onUserUpdate={updateUser} onBack={() => setScreen('main')} />;
  if (screen === 'game_crash') return <GameCrash user={user} onUserUpdate={updateUser} onBack={() => setScreen('main')} />;
  if (screen === 'referral') return <Referral user={user} onUserUpdate={updateUser} onBack={() => setScreen('main')} />;
  if (screen === 'wallet') return <Wallet user={user} onBack={() => setScreen('main')} />;

  const bigWins = getBigWins().slice(0, 10);

  const winRate = user.gamesPlayed > 0 ? Math.round((user.totalWon / ((user.totalWon + user.totalLost) || 1)) * 100) : 0;
  const nextVip: Record<number, number> = { 1: 50000, 2: 200000, 3: 500000, 4: 1000000, 5: 9999999 };
  const nextVipRequired = nextVip[user.vipLevel] || 9999999;
  const vipProgress = Math.min((user.totalDeposit / nextVipRequired) * 100, 100);

  return (
    <div className="min-h-screen bg-gray-900 text-white flex flex-col max-w-md mx-auto relative">
      {/* Bonus Modal */}
      {showBonusModal && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4" onClick={() => setShowBonusModal(false)}>
          <div className="bg-gray-800 rounded-3xl p-6 text-center border border-yellow-500 shadow-xl max-w-xs w-full" onClick={e => e.stopPropagation()}>
            <div className="text-5xl mb-4">🎁</div>
            <div className="text-lg font-bold mb-2">{bonusMsg}</div>
            <div className="text-sm text-gray-400 mb-4">موجودی: {user.balance.toLocaleString()} 🪙</div>
            <button onClick={() => setShowBonusModal(false)} className="bg-yellow-500 text-black font-bold px-8 py-2 rounded-xl">باشه!</button>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="bg-gradient-to-r from-gray-900 to-gray-800 px-4 pt-4 pb-2 border-b border-gray-700">
        <div className="flex items-center justify-between mb-2">
          <div>
            <div className="text-sm text-gray-400">سلام {user.firstName}! {VIP_NAMES[user.vipLevel]}</div>
            <div className="text-xs text-gray-500">@{user.username}</div>
          </div>
          <div className="text-right">
            <div className="text-xl font-black text-yellow-400">{user.balance.toLocaleString()} 🪙</div>
            <button onClick={claimDailyBonus} className="text-xs bg-green-700 hover:bg-green-600 text-white px-3 py-1 rounded-full mt-1 active:scale-95 transition-all">
              🎁 بونوس روزانه
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto pb-20">
        {/* Games Tab */}
        {tab === 'games' && (
          <div className="p-4">
            <div className="text-center text-sm text-gray-400 mb-4">بازی مورد نظر را انتخاب کنید</div>

            {/* Featured: Crash */}
            <button onClick={() => setScreen('game_crash')}
              className="w-full mb-3 bg-gradient-to-r from-orange-600 to-red-700 rounded-2xl p-4 flex items-center gap-4 active:scale-95 transition-all shadow-lg shadow-red-900/30 border border-orange-500/30">
              <div className="text-5xl">🚀</div>
              <div className="text-right flex-1">
                <div className="font-black text-lg">کراش</div>
                <div className="text-orange-300 text-sm">هر لحظه ممکن است کرش کند!</div>
                <div className="text-xs text-orange-200 mt-1">حداکثر برد: ∞x 🔥</div>
              </div>
              <div className="bg-orange-500 text-white text-xs font-bold px-2 py-1 rounded-lg">جدید!</div>
            </button>

            <div className="grid grid-cols-2 gap-3">
              {[
                { id: 'game_rps', icon: '✂️', name: 'سنگ کاغذ قیچی', mult: '1.8x', min: '500', color: 'from-blue-700 to-blue-800', border: 'border-blue-600/30' },
                { id: 'game_slot', icon: '🎰', name: 'اسلات شانس', mult: '7x', min: '1,000', color: 'from-purple-700 to-purple-800', border: 'border-purple-600/30' },
                { id: 'game_guess', icon: '🎯', name: 'حدس عدد', mult: '2.8x', min: '2,000', color: 'from-teal-700 to-teal-800', border: 'border-teal-600/30' },
                { id: 'game_dice', icon: '🎲', name: 'دوئل تاس', mult: '1.9x', min: '1,000', color: 'from-green-700 to-green-800', border: 'border-green-600/30' },
              ].map(g => (
                <button key={g.id} onClick={() => setScreen(g.id as Screen)}
                  className={`bg-gradient-to-b ${g.color} rounded-2xl p-4 flex flex-col items-center active:scale-95 transition-all shadow-lg border ${g.border}`}>
                  <div className="text-4xl mb-2">{g.icon}</div>
                  <div className="font-bold text-sm text-center">{g.name}</div>
                  <div className="text-green-300 text-xs mt-1">ضریب: {g.mult}</div>
                  <div className="text-gray-400 text-xs">حداقل: {g.min}</div>
                </button>
              ))}
            </div>

            {/* Big Wins */}
            <div className="mt-4">
              <div className="text-sm font-bold text-gray-300 mb-3 flex items-center gap-2">
                <span>🏆</span> بردهای اخیر
              </div>
              {bigWins.length === 0 ? (
                <div className="text-center text-gray-500 text-sm py-4">هنوز برد بزرگی ثبت نشده! اولین برنده باشید 🎯</div>
              ) : (
                <div className="space-y-2">
                  {bigWins.slice(0, 5).map((w, i) => {
                    const gameIcons: Record<string, string> = { rps: '✂️', slot: '🎰', guess: '🎯', dice: '🎲', crash: '🚀' };
                    return (
                      <div key={i} className="bg-gray-800 rounded-xl px-3 py-2 flex items-center gap-3">
                        <span className="text-xl">{gameIcons[w.gameType] || '🎮'}</span>
                        <div className="flex-1">
                          <span className="text-sm text-gray-300">@{w.username || 'ناشناس'}</span>
                        </div>
                        <span className="text-yellow-400 font-bold text-sm">{w.amount.toLocaleString()} 🪙</span>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Wallet Tab */}
        {tab === 'wallet' && (
          <div className="p-4">
            <div className="bg-gradient-to-r from-yellow-600 to-orange-600 rounded-2xl p-5 mb-4 text-center">
              <div className="text-sm text-yellow-200 mb-1">موجودی</div>
              <div className="text-4xl font-black">{user.balance.toLocaleString()} 🪙</div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <button onClick={() => setScreen('wallet')}
                className="bg-green-700 hover:bg-green-600 rounded-2xl p-4 text-center active:scale-95 transition-all">
                <div className="text-3xl mb-2">📥</div>
                <div className="font-bold">شارژ حساب</div>
                <div className="text-xs text-green-300">+۲۰٪ بونوس اول</div>
              </button>
              <button onClick={() => setScreen('wallet')}
                className="bg-red-700 hover:bg-red-600 rounded-2xl p-4 text-center active:scale-95 transition-all">
                <div className="text-3xl mb-2">📤</div>
                <div className="font-bold">برداشت</div>
                <div className="text-xs text-red-300">حداقل ۱۰,۰۰۰</div>
              </button>
            </div>

            <div className="mt-4 bg-gray-800 rounded-2xl p-4">
              <div className="font-bold mb-3 text-gray-300">آمار مالی</div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between"><span className="text-gray-400">کل شارژ:</span><span className="text-green-400">{user.totalDeposit.toLocaleString()} 🪙</span></div>
                <div className="flex justify-between"><span className="text-gray-400">کل برداشت:</span><span className="text-red-400">{user.totalWithdraw.toLocaleString()} 🪙</span></div>
                <div className="flex justify-between"><span className="text-gray-400">کل برد:</span><span className="text-yellow-400">{user.totalWon.toLocaleString()} 🪙</span></div>
                <div className="flex justify-between"><span className="text-gray-400">کل باخت:</span><span className="text-orange-400">{user.totalLost.toLocaleString()} 🪙</span></div>
              </div>
            </div>
          </div>
        )}

        {/* Stats Tab */}
        {tab === 'stats' && (
          <div className="p-4">
            {/* VIP Card */}
            <div className={`rounded-2xl p-5 mb-4 text-center relative overflow-hidden ${
              user.vipLevel >= 5 ? 'bg-gradient-to-r from-yellow-600 to-amber-500' :
              user.vipLevel >= 4 ? 'bg-gradient-to-r from-blue-700 to-cyan-600' :
              user.vipLevel >= 3 ? 'bg-gradient-to-r from-yellow-700 to-yellow-600' :
              user.vipLevel >= 2 ? 'bg-gradient-to-r from-gray-500 to-gray-400' :
              'bg-gradient-to-r from-orange-800 to-orange-700'
            }`}>
              <div className="text-4xl mb-1">{VIP_NAMES[user.vipLevel].split(' ')[0]}</div>
              <div className="text-xl font-black">{VIP_NAMES[user.vipLevel]}</div>
              {user.vipLevel < 5 && (
                <>
                  <div className="text-xs mt-2 opacity-80">تا سطح بعدی: {(nextVipRequired - user.totalDeposit).toLocaleString()} شارژ</div>
                  <div className="mt-2 bg-black/30 rounded-full h-2 overflow-hidden">
                    <div className="h-full bg-white/60 rounded-full transition-all" style={{ width: `${vipProgress}%` }} />
                  </div>
                </>
              )}
            </div>

            <div className="grid grid-cols-2 gap-3 mb-4">
              <div className="bg-gray-800 rounded-xl p-4 text-center">
                <div className="text-2xl font-black text-yellow-400">{user.gamesPlayed}</div>
                <div className="text-xs text-gray-400">بازی انجام شده</div>
              </div>
              <div className="bg-gray-800 rounded-xl p-4 text-center">
                <div className="text-2xl font-black text-green-400">{winRate}%</div>
                <div className="text-xs text-gray-400">درصد برد</div>
              </div>
              <div className="bg-gray-800 rounded-xl p-4 text-center">
                <div className="text-lg font-black text-green-300">{user.totalWon.toLocaleString()}</div>
                <div className="text-xs text-gray-400">کل برد 🪙</div>
              </div>
              <div className="bg-gray-800 rounded-xl p-4 text-center">
                <div className="text-lg font-black text-red-300">{user.totalLost.toLocaleString()}</div>
                <div className="text-xs text-gray-400">کل باخت 🪙</div>
              </div>
            </div>

            {/* VIP Table */}
            <div className="bg-gray-800 rounded-2xl p-4 mb-4">
              <div className="font-bold mb-3">⭐ سطح‌بندی VIP</div>
              <div className="space-y-2 text-sm">
                {[
                  { l: 1, name: '🥉 برنز', req: '0', bonus: 'x1.0' },
                  { l: 2, name: '🥈 نقره', req: '50,000', bonus: 'x1.05' },
                  { l: 3, name: '🥇 طلا', req: '200,000', bonus: 'x1.10' },
                  { l: 4, name: '💎 الماس', req: '500,000', bonus: 'x1.15' },
                  { l: 5, name: '👑 VIP', req: '1,000,000', bonus: 'x1.20' },
                ].map(v => (
                  <div key={v.l} className={`flex items-center gap-3 p-2 rounded-xl ${user.vipLevel === v.l ? 'bg-yellow-800/40 border border-yellow-600' : 'bg-gray-700/50'}`}>
                    <span className="w-20 font-bold text-xs">{v.name}</span>
                    <span className="flex-1 text-gray-400 text-xs">{v.req} شارژ</span>
                    <span className="text-green-400 text-xs font-bold">{v.bonus}</span>
                    {user.vipLevel === v.l && <span className="text-xs text-yellow-400">← شما</span>}
                  </div>
                ))}
              </div>
            </div>

            {/* Referral Button */}
            <button onClick={() => setScreen('referral')}
              className="w-full bg-gradient-to-r from-pink-700 to-purple-700 rounded-2xl p-4 flex items-center gap-4 active:scale-95 transition-all">
              <div className="text-4xl">👥</div>
              <div className="flex-1 text-right">
                <div className="font-bold">سیستم رفرال</div>
                <div className="text-sm text-pink-300">برای هر دعوت: ۴,۰۰۰ 🪙</div>
              </div>
              <div className="text-gray-300">←</div>
            </button>
          </div>
        )}

        {/* More Tab */}
        {tab === 'more' && (
          <div className="p-4 space-y-3">
            <div className="bg-gray-800 rounded-2xl p-4">
              <div className="font-bold text-lg mb-3 text-center">ℹ️ درباره GameiBox</div>
              <div className="space-y-3 text-sm text-gray-300">
                <div className="bg-gray-700 rounded-xl p-3">
                  <div className="font-bold text-white mb-1">🎮 بازی‌ها</div>
                  <div>سنگ کاغذ قیچی، اسلات، حدس عدد، تاس، کراش</div>
                </div>
                <div className="bg-gray-700 rounded-xl p-3">
                  <div className="font-bold text-white mb-1">💰 شارژ</div>
                  <div>BTC, LTC, TRX, USDT پشتیبانی می‌شود</div>
                  <div className="text-yellow-400 mt-1">اولین شارژ: +۲۰٪ بونوس!</div>
                </div>
                <div className="bg-gray-700 rounded-xl p-3">
                  <div className="font-bold text-white mb-1">🎁 بونوس‌ها</div>
                  <div>بونوس روزانه رایگان | رفرال: ۴,۰۰۰ سکه</div>
                </div>
                <div className="bg-gray-700 rounded-xl p-3">
                  <div className="font-bold text-white mb-1">📞 پشتیبانی</div>
                  <div>ادمین: @Supobox</div>
                  <div>ساعات پاسخگویی: ۲۴ ساعته</div>
                </div>
                <div className="bg-gray-700 rounded-xl p-3">
                  <div className="font-bold text-white mb-1">🔗 لینک‌ها</div>
                  <a href="https://t.me/+1PY8Xt8ksDowOWM0" target="_blank" rel="noreferrer" className="text-blue-400">گروه تلگرام</a>
                  <span className="mx-2 text-gray-500">|</span>
                  <a href="https://t.me/GameiboxBot" target="_blank" rel="noreferrer" className="text-blue-400">ربات تلگرام</a>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-gray-900 border-t border-gray-700 flex">
        {[
          { id: 'games', icon: '🎮', label: 'بازی‌ها' },
          { id: 'wallet', icon: '💰', label: 'کیف پول' },
          { id: 'stats', icon: '📊', label: 'آمار' },
          { id: 'more', icon: 'ℹ️', label: 'بیشتر' },
        ].map(t => (
          <button key={t.id} onClick={() => setTab(t.id as typeof tab)}
            className={`flex-1 py-3 flex flex-col items-center gap-1 transition-all ${tab === t.id ? 'text-yellow-400' : 'text-gray-500 hover:text-gray-300'}`}>
            <span className="text-xl">{t.icon}</span>
            <span className="text-xs">{t.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
