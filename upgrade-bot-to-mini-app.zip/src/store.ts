import { User, BigWin, GameSession } from './types';

const STORAGE_KEY = 'gameibox_data';
const WINS_KEY = 'gameibox_wins';
const SESSIONS_KEY = 'gameibox_sessions';

function generateCode(userId: number): string {
  return 'GB' + userId.toString(36).toUpperCase() + Math.random().toString(36).substring(2, 5).toUpperCase();
}

export function getTelegramUser(): { id: number; username: string; firstName: string } {
  try {
    const tg = (window as any).Telegram?.WebApp;
    if (tg?.initDataUnsafe?.user) {
      const u = tg.initDataUnsafe.user;
      return { id: u.id || 100001, username: u.username || 'user', firstName: u.first_name || 'کاربر' };
    }
  } catch {}
  return { id: 100001, username: 'testuser', firstName: 'کاربر تست' };
}

export function getUser(): User {
  const tgUser = getTelegramUser();
  const raw = localStorage.getItem(STORAGE_KEY + '_' + tgUser.id);
  if (raw) {
    const u = JSON.parse(raw) as User;
    u.username = tgUser.username;
    u.firstName = tgUser.firstName;
    return u;
  }
  // New user
  const now = new Date().toISOString();
  const user: User = {
    id: tgUser.id,
    username: tgUser.username,
    firstName: tgUser.firstName,
    balance: 5000,
    totalDeposit: 0,
    totalWithdraw: 0,
    totalWon: 0,
    totalLost: 0,
    gamesPlayed: 0,
    vipLevel: 1,
    dailyBonusDate: '',
    joinDate: now,
    referralCode: generateCode(tgUser.id),
    referredBy: null,
    referralCount: 0,
    referralEarnings: 0,
  };
  saveUser(user);
  return user;
}

export function saveUser(user: User): void {
  localStorage.setItem(STORAGE_KEY + '_' + user.id, JSON.stringify(user));
}

export function updateVIP(user: User): number {
  const levels: Record<number, number> = { 1: 0, 2: 50000, 3: 200000, 4: 500000, 5: 1000000 };
  let level = 1;
  for (const [lvl, req] of Object.entries(levels)) {
    if (user.totalDeposit >= req) level = parseInt(lvl);
  }
  user.vipLevel = level;
  return level;
}

export function getBigWins(): BigWin[] {
  const raw = localStorage.getItem(WINS_KEY);
  return raw ? JSON.parse(raw) : [];
}

export function addBigWin(win: BigWin): void {
  const wins = getBigWins();
  wins.unshift(win);
  localStorage.setItem(WINS_KEY, JSON.stringify(wins.slice(0, 50)));
}

export function getGameSessions(userId: number): GameSession[] {
  const raw = localStorage.getItem(SESSIONS_KEY + '_' + userId);
  return raw ? JSON.parse(raw) : [];
}

export function addGameSession(userId: number, session: Omit<GameSession, 'id'>): void {
  const sessions = getGameSessions(userId);
  const newSession: GameSession = { ...session, id: Date.now() };
  sessions.unshift(newSession);
  localStorage.setItem(SESSIONS_KEY + '_' + userId, JSON.stringify(sessions.slice(0, 100)));
}

export function applyReferral(user: User, code: string): boolean {
  if (!code || code === user.referralCode || user.referredBy) return false;
  // Find referrer
  const keys = Object.keys(localStorage).filter(k => k.startsWith(STORAGE_KEY + '_'));
  for (const key of keys) {
    const raw = localStorage.getItem(key);
    if (!raw) continue;
    const u = JSON.parse(raw) as User;
    if (u.referralCode === code) {
      // Give reward to referrer
      u.balance += 4000;
      u.referralCount += 1;
      u.referralEarnings += 4000;
      saveUser(u);
      // Mark this user as referred
      user.referredBy = code;
      user.balance += 2000; // Bonus for new user
      saveUser(user);
      return true;
    }
  }
  return false;
}
