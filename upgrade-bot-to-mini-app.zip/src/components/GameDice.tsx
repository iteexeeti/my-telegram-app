import { useState } from 'react';
import { User } from '../types';
import { saveUser, addBigWin, addGameSession } from '../store';

interface Props {
  user: User;
  onUserUpdate: (u: User) => void;
  onBack: () => void;
}

const BETS = [1000, 2000, 5000, 10000, 50000];
const MIN_BET = 1000;
const MULTIPLIER = 1.9;

const DICE_FACES = ['', '1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣'];

export default function GameDice({ user, onUserUpdate, onBack }: Props) {
  const [bet, setBet] = useState(1000);
  const [customBet, setCustomBet] = useState('');
  const [rolling, setRolling] = useState(false);
  const [playerDice, setPlayerDice] = useState<number | null>(null);
  const [botDice, setBotDice] = useState<number | null>(null);
  const [result, setResult] = useState<'win' | 'lose' | 'draw' | null>(null);
  const [profit, setProfit] = useState(0);

  const currentBet = customBet ? parseInt(customBet) || 0 : bet;

  function rollDice() {
    if (rolling || currentBet < MIN_BET || currentBet > user.balance) return;
    setRolling(true);
    setResult(null);

    let count = 0;
    const interval = setInterval(() => {
      setPlayerDice(Math.floor(Math.random() * 6) + 1);
      setBotDice(Math.floor(Math.random() * 6) + 1);
      count++;
      if (count >= 15) {
        clearInterval(interval);
        finalizeRoll();
      }
    }, 80);
  }

  function finalizeRoll() {
    let houseEdge = 0.50;
    if (currentBet >= 50000) houseEdge = 0.75;
    else if (currentBet >= 20000) houseEdge = 0.70;
    else if (currentBet >= 10000) houseEdge = 0.65;
    else if (currentBet >= 5000) houseEdge = 0.58;

    const pd = Math.floor(Math.random() * 6) + 1;
    let bd: number;

    if (Math.random() < houseEdge) {
      if (pd < 6) bd = Math.floor(Math.random() * (6 - pd)) + pd + 1;
      else bd = 6;
    } else {
      bd = Math.floor(Math.random() * 6) + 1;
    }

    setPlayerDice(pd);
    setBotDice(bd);

    let res: 'win' | 'lose' | 'draw';
    let p = 0;

    const updatedUser = { ...user };
    if (pd > bd) {
      res = 'win';
      p = Math.floor(currentBet * MULTIPLIER) - currentBet;
      updatedUser.balance += p;
      updatedUser.totalWon += p + currentBet;
      addBigWin({ username: user.username, gameType: 'dice', amount: p + currentBet, date: new Date().toISOString() });
    } else if (pd === bd) {
      res = 'draw';
    } else {
      res = 'lose';
      p = -currentBet;
      updatedUser.balance -= currentBet;
      updatedUser.totalLost += currentBet;
    }
    setResult(res);
    setProfit(p);
    updatedUser.gamesPlayed += 1;

    addGameSession(user.id, { gameType: 'dice', betAmount: currentBet, result: res, profitLoss: p, date: new Date().toISOString() });
    saveUser(updatedUser);
    onUserUpdate(updatedUser);
    setRolling(false);
  }

  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-b from-green-900 to-gray-900 text-white p-4">
      <div className="flex items-center gap-3 mb-6">
        <button onClick={onBack} className="text-gray-400 hover:text-white text-xl">←</button>
        <h1 className="text-xl font-bold">🎲 دوئل تاس</h1>
        <div className="mr-auto text-sm text-yellow-400 font-bold">💰 {user.balance.toLocaleString()}</div>
      </div>

      <div className="bg-green-800/40 rounded-2xl p-4 mb-6 text-center border border-green-700">
        <div className="text-gray-300 text-sm">عدد بزرگتر می‌برد | ضریب {MULTIPLIER}x</div>
      </div>

      {/* Dice Display */}
      <div className="flex items-center justify-center gap-8 mb-6">
        <div className="text-center">
          <div className={`text-8xl mb-2 ${rolling ? 'animate-spin' : ''}`}>
            {playerDice ? DICE_FACES[playerDice] : '🎲'}
          </div>
          <div className="text-sm text-gray-400">شما</div>
          {playerDice && <div className="text-lg font-bold text-white">{playerDice}</div>}
        </div>

        <div className="text-3xl text-gray-500 font-black">VS</div>

        <div className="text-center">
          <div className={`text-8xl mb-2 ${rolling ? 'animate-spin' : ''}`}>
            {botDice ? DICE_FACES[botDice] : '🎲'}
          </div>
          <div className="text-sm text-gray-400">ربات</div>
          {botDice && <div className="text-lg font-bold text-white">{botDice}</div>}
        </div>
      </div>

      {/* Result */}
      {result && !rolling && (
        <div className={`text-center p-4 rounded-2xl mb-4 ${result === 'win' ? 'bg-green-900/50 border border-green-500' : result === 'lose' ? 'bg-red-900/50 border border-red-500' : 'bg-gray-700 border border-gray-500'}`}>
          <div className="text-2xl font-bold">{result === 'win' ? '🎉 بردید!' : result === 'lose' ? '😔 باختید!' : '🤝 مساوی!'}</div>
          {result !== 'draw' && <div className={`font-bold mt-1 ${profit > 0 ? 'text-green-300' : 'text-red-300'}`}>
            {profit > 0 ? '+' : ''}{profit.toLocaleString()} 🪙
          </div>}
        </div>
      )}

      {/* Bet Selection */}
      <div className="mb-4">
        <div className="text-gray-300 text-sm mb-2">انتخاب شرط:</div>
        <div className="grid grid-cols-5 gap-1 mb-2">
          {BETS.map(b => (
            <button key={b} onClick={() => { setBet(b); setCustomBet(''); }}
              className={`py-2 rounded-xl text-xs font-bold ${bet === b && !customBet ? 'bg-green-500 text-white' : 'bg-gray-700 text-white'}`}>
              {(b / 1000)}K
            </button>
          ))}
        </div>
        <input type="number" placeholder="مبلغ دلخواه..." value={customBet}
          onChange={e => setCustomBet(e.target.value)}
          className="w-full bg-gray-700 rounded-xl px-4 py-2 text-white text-center placeholder-gray-500 focus:outline-none" />
      </div>

      <div className="text-center text-sm text-gray-400 mb-3">
        شرط: <span className="text-yellow-400 font-bold">{currentBet.toLocaleString()}</span> | برد: <span className="text-green-400 font-bold">{Math.floor(currentBet * MULTIPLIER).toLocaleString()}</span>
      </div>

      <button onClick={rollDice} disabled={rolling || currentBet < MIN_BET || currentBet > user.balance}
        className={`w-full py-4 rounded-2xl text-lg font-bold transition-all ${!rolling && currentBet >= MIN_BET && currentBet <= user.balance
          ? 'bg-gradient-to-r from-green-500 to-teal-500 text-white hover:opacity-90 active:scale-95'
          : 'bg-gray-600 text-gray-400 cursor-not-allowed'}`}>
        {rolling ? '🎲 در حال پرتاب...' : `🎲 پرتاب! (${currentBet.toLocaleString()} 🪙)`}
      </button>
    </div>
  );
}
