import { useState, useEffect, useRef } from 'react';
import { User } from '../types';
import { saveUser, addBigWin, addGameSession } from '../store';

interface Props {
  user: User;
  onUserUpdate: (u: User) => void;
  onBack: () => void;
}

const BETS = [1000, 2000, 5000, 10000, 50000];
const MIN_BET = 1000;

export default function GameCrash({ user, onUserUpdate, onBack }: Props) {
  const [bet, setBet] = useState(1000);
  const [customBet, setCustomBet] = useState('');
  const [phase, setPhase] = useState<'idle' | 'running' | 'crashed' | 'won'>('idle');
  const [multiplier, setMultiplier] = useState(1.00);
  const [crashAt, setCrashAt] = useState(1.00);
  const [cashedOut, setCashedOut] = useState(false);
  const [profit, setProfit] = useState(0);
  const [autoStopAt, setAutoStopAt] = useState('');
  const [history, setHistory] = useState<number[]>([2.3, 1.5, 8.2, 1.1, 3.4, 1.8, 12.5, 1.3]);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const multiplierRef = useRef(1.00);
  const cashedRef = useRef(false);
  const currentBet = customBet ? parseInt(customBet) || 0 : bet;

  function generateCrashPoint(): number {
    const r = Math.random();
    // House edge ~5%
    if (r < 0.05) return 1.00;
    if (r < 0.30) return 1.0 + Math.random() * 0.5;
    if (r < 0.60) return 1.5 + Math.random() * 1.5;
    if (r < 0.80) return 3 + Math.random() * 5;
    if (r < 0.95) return 8 + Math.random() * 12;
    return 20 + Math.random() * 30;
  }

  function startGame() {
    if (currentBet < MIN_BET || currentBet > user.balance) return;
    const cp = generateCrashPoint();
    setCrashAt(cp);
    setPhase('running');
    setCashedOut(false);
    cashedRef.current = false;
    multiplierRef.current = 1.00;
    setMultiplier(1.00);

    intervalRef.current = setInterval(() => {
      multiplierRef.current = parseFloat((multiplierRef.current + 0.04).toFixed(2));
      setMultiplier(multiplierRef.current);

      // Auto cash out
      const autoVal = parseFloat(autoStopAt);
      if (autoStopAt && autoVal >= 1.01 && multiplierRef.current >= autoVal && !cashedRef.current) {
        cashOut();
        return;
      }

      if (multiplierRef.current >= cp) {
        if (intervalRef.current) clearInterval(intervalRef.current);
        if (!cashedRef.current) {
          setPhase('crashed');
          setProfit(-currentBet);
          const updatedUser = { ...user };
          updatedUser.balance -= currentBet;
          updatedUser.totalLost += currentBet;
          updatedUser.gamesPlayed += 1;
          addGameSession(user.id, { gameType: 'crash', betAmount: currentBet, result: 'lose', profitLoss: -currentBet, date: new Date().toISOString() });
          saveUser(updatedUser);
          onUserUpdate(updatedUser);
          setHistory(h => [parseFloat(cp.toFixed(2)), ...h.slice(0, 7)]);
        }
      }
    }, 100);
  }

  function cashOut() {
    if (cashedRef.current || phase !== 'running') return;
    cashedRef.current = true;
    setCashedOut(true);
    if (intervalRef.current) clearInterval(intervalRef.current);

    const currentMult = multiplierRef.current;
    const gain = Math.floor(currentBet * currentMult) - currentBet;
    setProfit(gain);
    setPhase('won');

    const updatedUser = { ...user };
    updatedUser.balance += gain;
    updatedUser.totalWon += gain + currentBet;
    updatedUser.gamesPlayed += 1;
    if (gain > 5000) addBigWin({ username: user.username, gameType: 'crash', amount: gain + currentBet, date: new Date().toISOString() });
    addGameSession(user.id, { gameType: 'crash', betAmount: currentBet, result: 'win', profitLoss: gain, date: new Date().toISOString() });
    saveUser(updatedUser);
    onUserUpdate(updatedUser);
  }

  useEffect(() => {
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, []);

  const mColor = multiplier >= 5 ? 'text-green-300' : multiplier >= 2 ? 'text-yellow-300' : 'text-white';

  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-b from-gray-900 to-black text-white p-4">
      <div className="flex items-center gap-3 mb-4">
        <button onClick={onBack} className="text-gray-400 hover:text-white text-xl">←</button>
        <h1 className="text-xl font-bold">🚀 کراش</h1>
        <div className="mr-auto text-sm text-yellow-400 font-bold">💰 {user.balance.toLocaleString()}</div>
      </div>

      {/* History */}
      <div className="flex gap-2 mb-4 overflow-x-auto pb-1">
        {history.map((h, i) => (
          <div key={i} className={`flex-shrink-0 px-3 py-1 rounded-full text-xs font-bold ${h >= 2 ? 'bg-green-800 text-green-300' : 'bg-red-900 text-red-400'}`}>
            {h.toFixed(2)}x
          </div>
        ))}
      </div>

      {/* Main Display */}
      <div className={`relative bg-gradient-to-b rounded-3xl p-8 mb-4 flex flex-col items-center justify-center min-h-48 border-2 transition-all duration-300
        ${phase === 'crashed' ? 'from-red-900 to-red-950 border-red-500' : phase === 'won' ? 'from-green-900 to-green-950 border-green-500' : 'from-gray-800 to-gray-900 border-gray-600'}`}>

        {phase === 'idle' && (
          <div className="text-center">
            <div className="text-6xl mb-2">🚀</div>
            <div className="text-gray-400">آماده برای پرواز!</div>
          </div>
        )}

        {phase === 'running' && (
          <div className="text-center">
            <div className="text-7xl animate-bounce mb-2">🚀</div>
            <div className={`text-6xl font-black ${mColor}`}>{multiplier.toFixed(2)}x</div>
            <div className="text-gray-400 mt-2">در حال پرواز...</div>
          </div>
        )}

        {phase === 'crashed' && (
          <div className="text-center">
            <div className="text-6xl mb-2">💥</div>
            <div className="text-red-400 text-4xl font-black">{crashAt.toFixed(2)}x</div>
            <div className="text-red-300 text-lg mt-2">کرش کرد!</div>
            <div className="text-red-300 font-bold">{profit.toLocaleString()} 🪙</div>
          </div>
        )}

        {phase === 'won' && (
          <div className="text-center">
            <div className="text-6xl mb-2">💰</div>
            <div className="text-green-400 text-4xl font-black">{multiplier.toFixed(2)}x</div>
            <div className="text-green-300 text-lg mt-2">موفق خارج شدید!</div>
            <div className="text-green-300 font-bold">+{profit.toLocaleString()} 🪙</div>
          </div>
        )}
      </div>

      {/* Controls */}
      {(phase === 'idle' || phase === 'crashed' || phase === 'won') && (
        <>
          <div className="mb-3">
            <div className="text-sm text-gray-400 mb-2">شرط:</div>
            <div className="grid grid-cols-5 gap-1 mb-2">
              {BETS.map(b => (
                <button key={b} onClick={() => { setBet(b); setCustomBet(''); }}
                  className={`py-2 rounded-xl text-xs font-bold ${bet === b && !customBet ? 'bg-orange-500 text-white' : 'bg-gray-700 text-white'}`}>
                  {(b / 1000).toLocaleString()}K
                </button>
              ))}
            </div>
            <div className="grid grid-cols-2 gap-2">
              <input type="number" placeholder="مبلغ دلخواه..." value={customBet}
                onChange={e => setCustomBet(e.target.value)}
                className="bg-gray-700 rounded-xl px-3 py-2 text-white text-sm text-center placeholder-gray-500 focus:outline-none" />
              <input type="number" placeholder="خروج خودکار در Xx" value={autoStopAt}
                onChange={e => setAutoStopAt(e.target.value)}
                className="bg-gray-700 rounded-xl px-3 py-2 text-white text-sm text-center placeholder-gray-500 focus:outline-none" />
            </div>
          </div>

          <button onClick={startGame} disabled={currentBet < MIN_BET || currentBet > user.balance}
            className={`w-full py-4 rounded-2xl text-lg font-bold ${currentBet >= MIN_BET && currentBet <= user.balance
              ? 'bg-gradient-to-r from-orange-500 to-red-500 text-white hover:opacity-90 active:scale-95'
              : 'bg-gray-600 text-gray-400 cursor-not-allowed'}`}>
            🚀 {phase === 'idle' ? `شروع (${currentBet.toLocaleString()})` : 'بازی مجدد'}
          </button>
        </>
      )}

      {phase === 'running' && (
        <button onClick={cashOut} disabled={cashedOut}
          className={`w-full py-5 rounded-2xl text-xl font-bold transition-all ${cashedOut
            ? 'bg-gray-600 text-gray-400 cursor-not-allowed'
            : 'bg-gradient-to-r from-green-500 to-emerald-500 text-white hover:opacity-90 active:scale-95 shadow-lg shadow-green-900 animate-pulse'}`}>
          💰 خروج! ({Math.floor(currentBet * multiplier).toLocaleString()} 🪙)
        </button>
      )}
    </div>
  );
}
