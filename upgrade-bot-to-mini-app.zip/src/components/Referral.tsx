import { useState } from 'react';
import { User } from '../types';
import { saveUser, applyReferral } from '../store';

interface Props {
  user: User;
  onUserUpdate: (u: User) => void;
  onBack: () => void;
}

export default function Referral({ user, onUserUpdate, onBack }: Props) {
  const [inputCode, setInputCode] = useState('');
  const [message, setMessage] = useState('');
  const [copied, setCopied] = useState(false);

  const botUsername = 'GameiboxBot';
  const referralLink = `https://t.me/${botUsername}?start=ref_${user.referralCode}`;

  function copyLink() {
    navigator.clipboard.writeText(referralLink).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  }

  function copyCode() {
    navigator.clipboard.writeText(user.referralCode).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  }

  function submitCode() {
    if (!inputCode.trim()) {
      setMessage('❌ لطفا کد رفرال را وارد کنید');
      return;
    }
    if (user.referredBy) {
      setMessage('❌ شما قبلاً با یک کد رفرال ثبت‌نام کرده‌اید!');
      return;
    }
    if (inputCode.trim() === user.referralCode) {
      setMessage('❌ نمی‌توانید از کد رفرال خودتان استفاده کنید!');
      return;
    }
    const updated = { ...user };
    const success = applyReferral(updated, inputCode.trim().toUpperCase());
    if (success) {
      saveUser(updated);
      onUserUpdate(updated);
      setMessage('✅ کد رفرال اعمال شد! ۲۰۰۰ سکه به شما و ۴۰۰۰ سکه به دوستتان اضافه شد!');
      setInputCode('');
    } else {
      setMessage('❌ کد رفرال نامعتبر است یا قبلاً استفاده شده.');
    }
  }

  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-b from-pink-900 to-gray-900 text-white p-4">
      <div className="flex items-center gap-3 mb-6">
        <button onClick={onBack} className="text-gray-400 hover:text-white text-xl">←</button>
        <h1 className="text-xl font-bold">👥 سیستم رفرال</h1>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-3 mb-6">
        <div className="bg-pink-800/40 rounded-2xl p-4 text-center border border-pink-700">
          <div className="text-3xl font-black text-pink-300">{user.referralCount}</div>
          <div className="text-sm text-gray-400">دعوت شده</div>
        </div>
        <div className="bg-yellow-800/40 rounded-2xl p-4 text-center border border-yellow-700">
          <div className="text-2xl font-black text-yellow-300">{user.referralEarnings.toLocaleString()}</div>
          <div className="text-sm text-gray-400">سکه درآمد</div>
        </div>
      </div>

      {/* How it works */}
      <div className="bg-gray-800/60 rounded-2xl p-4 mb-6 border border-gray-700">
        <div className="text-center text-lg font-bold mb-3 text-pink-300">🎁 نحوه کارکرد</div>
        <div className="space-y-3 text-sm">
          <div className="flex items-center gap-3 bg-gray-700/50 rounded-xl p-3">
            <span className="text-2xl">1️⃣</span>
            <span className="text-gray-300">لینک اختصاصی خود را با دوستانتان به اشتراک بگذارید</span>
          </div>
          <div className="flex items-center gap-3 bg-gray-700/50 rounded-xl p-3">
            <span className="text-2xl">2️⃣</span>
            <span className="text-gray-300">دوست شما ربات را شروع کرده و ثبت‌نام می‌کند</span>
          </div>
          <div className="flex items-center gap-3 bg-gray-700/50 rounded-xl p-3">
            <span className="text-2xl">3️⃣</span>
            <div>
              <span className="text-yellow-400 font-bold">شما: ۴۰۰۰ 🪙 جایزه</span>
              <br />
              <span className="text-green-400 font-bold">دوستتان: ۲۰۰۰ 🪙 هدیه خوش‌آمد</span>
            </div>
          </div>
        </div>
      </div>

      {/* Referral Code */}
      <div className="bg-gradient-to-r from-pink-800/40 to-purple-800/40 rounded-2xl p-4 mb-4 border border-pink-600">
        <div className="text-sm text-gray-400 mb-2 text-center">کد رفرال اختصاصی شما:</div>
        <div className="text-center text-2xl font-black text-pink-300 tracking-widest mb-3">{user.referralCode}</div>
        <button onClick={copyCode} className="w-full bg-pink-600 hover:bg-pink-500 text-white py-2 rounded-xl text-sm font-bold transition-all active:scale-95 mb-2">
          {copied ? '✅ کپی شد!' : '📋 کپی کد'}
        </button>
        <button onClick={copyLink} className="w-full bg-purple-600 hover:bg-purple-500 text-white py-2 rounded-xl text-sm font-bold transition-all active:scale-95">
          🔗 کپی لینک دعوت
        </button>
      </div>

      {/* Share Link */}
      <div className="bg-gray-800/60 rounded-xl p-3 mb-4 border border-gray-700">
        <div className="text-xs text-gray-500 mb-1">لینک دعوت:</div>
        <div className="text-xs text-blue-400 break-all">{referralLink}</div>
      </div>

      {/* Enter Referral Code */}
      {!user.referredBy && (
        <div className="bg-gray-800/60 rounded-2xl p-4 border border-gray-700">
          <div className="text-center text-sm font-bold mb-3 text-gray-300">وارد کردن کد رفرال</div>
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="کد رفرال دوستتان..."
              value={inputCode}
              onChange={e => setInputCode(e.target.value.toUpperCase())}
              className="flex-1 bg-gray-700 rounded-xl px-3 py-2 text-white text-sm placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-pink-500 uppercase"
            />
            <button onClick={submitCode}
              className="bg-pink-500 hover:bg-pink-400 text-white px-4 py-2 rounded-xl text-sm font-bold active:scale-95">
              اعمال
            </button>
          </div>
          {message && (
            <div className={`mt-3 text-sm text-center p-2 rounded-xl ${message.includes('✅') ? 'bg-green-900/50 text-green-300' : 'bg-red-900/50 text-red-300'}`}>
              {message}
            </div>
          )}
        </div>
      )}

      {user.referredBy && (
        <div className="bg-green-900/30 rounded-xl p-3 text-center border border-green-700 mt-2">
          <div className="text-green-400 text-sm">✅ شما با کد رفرال ثبت‌نام کرده‌اید</div>
        </div>
      )}
    </div>
  );
}
