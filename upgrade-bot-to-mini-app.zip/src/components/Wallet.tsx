import { useState } from 'react';
import { User } from '../types';

interface Props {
  user: User;
  onBack: () => void;
}

const WALLETS = {
  BTC: { address: 'bc1qwnqgqvcrh9czxfjpr6gaydlck9vd49qngljtqm', name: 'Bitcoin', emoji: '₿' },
  LTC: { address: 'ltc1qea2hzhlxalfs4taa7veh6vx30at4s00n3yjjly', name: 'Litecoin', emoji: 'Ł' },
  TRX: { address: 'TEWgJXHnKwmLiRc23eSZ1CknC7AP6srUxF', name: 'TRON', emoji: 'T' },
  USDT: { address: 'TEWgJXHnKwmLiRc23eSZ1CknC7AP6srUxF', name: 'Tether TRC20', emoji: '$' },
};

export default function Wallet({ user, onBack }: Props) {
  const [tab, setTab] = useState<'deposit' | 'withdraw'>('deposit');
  const [selectedCoin, setSelectedCoin] = useState<keyof typeof WALLETS | null>(null);
  const [copied, setCopied] = useState(false);
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [withdrawAddress, setWithdrawAddress] = useState('');
  const [txid, setTxid] = useState('');
  const [step, setStep] = useState<'select' | 'address' | 'confirm'>('select');
  const [wStep, setWStep] = useState<'form' | 'sent'>('form');

  function copyAddress(addr: string) {
    navigator.clipboard.writeText(addr);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  function sendDepositRequest() {
    if (!txid.trim() || !selectedCoin) return;
    // In real bot, this would be sent to backend/bot
    const tg = (window as any).Telegram?.WebApp;
    if (tg) {
      tg.sendData(JSON.stringify({ type: 'deposit', coin: selectedCoin, txid: txid.trim() }));
    } else {
      alert(`درخواست شارژ ثبت شد!\nارز: ${selectedCoin}\nTXID: ${txid}\n\nبرای تایید با ادمین در تماس باشید: @Supobox`);
    }
    setStep('confirm');
  }

  function sendWithdrawRequest() {
    if (!withdrawAmount || !withdrawAddress.trim()) return;
    const tg = (window as any).Telegram?.WebApp;
    if (tg) {
      tg.sendData(JSON.stringify({ type: 'withdraw', coin: 'LTC', amount: withdrawAmount, address: withdrawAddress }));
    } else {
      alert(`درخواست برداشت ثبت شد!\nمقدار: ${withdrawAmount} سکه\nآدرس: ${withdrawAddress}\n\nبرای تایید با ادمین در تماس باشید: @Supobox`);
    }
    setWStep('sent');
  }

  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-b from-gray-900 to-gray-800 text-white p-4">
      <div className="flex items-center gap-3 mb-6">
        <button onClick={onBack} className="text-gray-400 hover:text-white text-xl">←</button>
        <h1 className="text-xl font-bold">💰 کیف پول</h1>
      </div>

      {/* Balance */}
      <div className="bg-gradient-to-r from-yellow-600 to-orange-600 rounded-2xl p-5 mb-6 text-center shadow-lg">
        <div className="text-sm text-yellow-200 mb-1">موجودی شما</div>
        <div className="text-4xl font-black">{user.balance.toLocaleString()} 🪙</div>
        <div className="flex justify-around mt-3 text-xs text-yellow-200">
          <div>کل شارژ: {user.totalDeposit.toLocaleString()}</div>
          <div>کل برداشت: {user.totalWithdraw.toLocaleString()}</div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 mb-4">
        <button onClick={() => { setTab('deposit'); setStep('select'); setSelectedCoin(null); }}
          className={`flex-1 py-3 rounded-xl font-bold text-sm ${tab === 'deposit' ? 'bg-green-600 text-white' : 'bg-gray-700 text-gray-300'}`}>
          📥 شارژ حساب
        </button>
        <button onClick={() => { setTab('withdraw'); setWStep('form'); }}
          className={`flex-1 py-3 rounded-xl font-bold text-sm ${tab === 'withdraw' ? 'bg-red-600 text-white' : 'bg-gray-700 text-gray-300'}`}>
          📤 برداشت
        </button>
      </div>

      {/* Deposit */}
      {tab === 'deposit' && (
        <>
          {step === 'select' && (
            <div className="space-y-3">
              <div className="text-center text-sm text-yellow-400 mb-2">🎁 اولین شارژ: ۲۰٪ بونوس!</div>
              {Object.entries(WALLETS).map(([coin, info]) => (
                <button key={coin} onClick={() => { setSelectedCoin(coin as keyof typeof WALLETS); setStep('address'); }}
                  className="w-full bg-gray-700 hover:bg-gray-600 rounded-2xl p-4 flex items-center gap-4 active:scale-95 transition-all border border-gray-600 hover:border-gray-400">
                  <div className="w-12 h-12 bg-gray-800 rounded-full flex items-center justify-center text-2xl font-bold">
                    {info.emoji}
                  </div>
                  <div className="text-right">
                    <div className="font-bold">{info.name}</div>
                    <div className="text-sm text-gray-400">{coin}</div>
                  </div>
                  <div className="mr-auto text-gray-400">←</div>
                </button>
              ))}
            </div>
          )}

          {step === 'address' && selectedCoin && (
            <div className="space-y-4">
              <div className="bg-gray-700 rounded-2xl p-4">
                <div className="text-sm text-gray-400 mb-2">آدرس واریز {WALLETS[selectedCoin].name}:</div>
                <div className="bg-gray-800 rounded-xl p-3 text-xs text-green-400 break-all font-mono mb-3">
                  {WALLETS[selectedCoin].address}
                </div>
                <button onClick={() => copyAddress(WALLETS[selectedCoin].address)}
                  className={`w-full py-2 rounded-xl text-sm font-bold ${copied ? 'bg-green-600' : 'bg-blue-600 hover:bg-blue-500'}`}>
                  {copied ? '✅ کپی شد!' : '📋 کپی آدرس'}
                </button>
              </div>

              <div className="bg-yellow-900/30 rounded-xl p-3 border border-yellow-700 text-sm text-yellow-300">
                ⚠️ پس از واریز، TXID تراکنش را وارد کنید تا شارژتان تایید شود.
              </div>

              <div>
                <div className="text-sm text-gray-400 mb-2">TXID تراکنش:</div>
                <input type="text" placeholder="TXID را وارد کنید..." value={txid}
                  onChange={e => setTxid(e.target.value)}
                  className="w-full bg-gray-700 rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-green-500 text-sm" />
              </div>

              <div className="flex gap-3">
                <button onClick={() => setStep('select')} className="flex-1 bg-gray-700 py-3 rounded-xl text-sm">← بازگشت</button>
                <button onClick={sendDepositRequest} disabled={!txid.trim()}
                  className={`flex-2 flex-grow py-3 rounded-xl text-sm font-bold ${txid.trim() ? 'bg-green-600 hover:bg-green-500' : 'bg-gray-600 text-gray-400 cursor-not-allowed'}`}>
                  ✅ ارسال درخواست
                </button>
              </div>
            </div>
          )}

          {step === 'confirm' && (
            <div className="text-center py-8">
              <div className="text-6xl mb-4">✅</div>
              <div className="text-xl font-bold text-green-400 mb-2">درخواست ثبت شد!</div>
              <div className="text-gray-400 text-sm mb-6">پس از تایید ادمین، موجودی اضافه می‌شود.<br />معمولاً ۲ تا ۲۴ ساعت طول می‌کشد.</div>
              <div className="text-gray-500 text-xs">ادمین: @Supobox</div>
              <button onClick={() => setStep('select')} className="mt-4 bg-gray-700 px-6 py-2 rounded-xl text-sm">شارژ مجدد</button>
            </div>
          )}
        </>
      )}

      {/* Withdraw */}
      {tab === 'withdraw' && (
        <>
          {wStep === 'form' && (
            <div className="space-y-4">
              <div className="bg-red-900/30 rounded-xl p-3 border border-red-700 text-sm text-red-300">
                ⚠️ فعلاً فقط برداشت از طریق Litecoin فعال است
              </div>
              <div className="text-sm text-gray-400">حداقل برداشت: <span className="text-yellow-400 font-bold">۱۰,۰۰۰ 🪙</span></div>

              <div>
                <div className="text-sm text-gray-400 mb-2">مبلغ برداشت (سکه):</div>
                <input type="number" placeholder="مقدار را وارد کنید..." value={withdrawAmount}
                  onChange={e => setWithdrawAmount(e.target.value)}
                  className="w-full bg-gray-700 rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-red-500" />
              </div>

              <div>
                <div className="text-sm text-gray-400 mb-2">آدرس LTC:</div>
                <input type="text" placeholder="آدرس Litecoin..." value={withdrawAddress}
                  onChange={e => setWithdrawAddress(e.target.value)}
                  className="w-full bg-gray-700 rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-red-500 text-sm" />
              </div>

              <button onClick={sendWithdrawRequest}
                disabled={!withdrawAmount || parseInt(withdrawAmount) < 10000 || parseInt(withdrawAmount) > user.balance || !withdrawAddress.trim()}
                className={`w-full py-4 rounded-xl font-bold ${withdrawAmount && parseInt(withdrawAmount) >= 10000 && parseInt(withdrawAmount) <= user.balance && withdrawAddress.trim()
                  ? 'bg-red-600 hover:bg-red-500 text-white'
                  : 'bg-gray-600 text-gray-400 cursor-not-allowed'}`}>
                📤 ارسال درخواست برداشت
              </button>

              {withdrawAmount && parseInt(withdrawAmount) > user.balance && (
                <div className="text-red-400 text-sm text-center">❌ موجودی کافی ندارید!</div>
              )}
            </div>
          )}

          {wStep === 'sent' && (
            <div className="text-center py-8">
              <div className="text-6xl mb-4">📤</div>
              <div className="text-xl font-bold text-yellow-400 mb-2">درخواست برداشت ثبت شد!</div>
              <div className="text-gray-400 text-sm mb-4">برداشت در ۲ تا ۲۴ ساعت پردازش می‌شود.</div>
              <div className="text-gray-500 text-xs">ادمین: @Supobox</div>
              <button onClick={() => setWStep('form')} className="mt-4 bg-gray-700 px-6 py-2 rounded-xl text-sm">درخواست جدید</button>
            </div>
          )}
        </>
      )}
    </div>
  );
}
