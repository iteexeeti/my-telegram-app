import { useState } from 'react';
import { User } from '../types';
import { saveUser, addBigWin, addGameSession } from '../store';

interface Props {
  user: User;
  onUserUpdate: (u: User) => void;
  onBack: () => void;
}

const SYMBOLS = ['🍒', '🍋', '🍊', '⭐', '💎', '7️⃣', '🎰'];
const WEIGHTS = [35, 28, 20, 10, 5, 1.5, 0.5];
const BETS = [1000, 2000, 5000, 10000, 50000, 100000];
const MIN_BET = 1000;

function weightedRandom(): string {
  const total = WEIGHTS.reduce((a, b) => a + b, 0);
  let r = Math.random() * total;
  for (let i = 0; i < SYMBOLS.length; i++) {
    r -= WEIGHTS[i];
    if (r <= 0) return SYMBOLS[i];
  }
  return SYMBOLS[0];
}

export default function GameSlot({ user, onUserUpdate, onBack }: Props) {
  const [bet, setBet] = useState(1000);
  const [customBet, setCustomBet] = useState('');
  const [spinning, setSpinning] = useState(false);
  const [reels, setReels] = useState(['🎰', '🎰', '🎰']);
  const [result, setResult] = useState<'win' | 'lose' | 'draw' | null>(null);
  const [profit, setProfit] = useState(0);
  const [multiplier, setMultiplier] = useState(0);

  const currentBet = customBet ? parseInt(customBet) || 0 : bet;

  function spin() {
    if (spinning || currentBet < MIN_BET || currentBet > user.balance) return;
    setSpinning(true);
    setResult(null);

    // Animate reels
    let count = 0;
    const interval = setInterval(() => {
      setReels([weightedRandom(), weightedRandom(), weightedRandom()]);
      count++;
      if (count > 10) {
        clearInterval(interval);
        finalizeSpin();
      }
    }, 80);
  }

  function finalizeSpin() {
    let houseEdge = 0.60;
    if (currentBet >= 50000) houseEdge = 0.85;
    else if (currentBet >= 20000) houseEdge = 0.80;
    else if (currentBet >= 10000) houseEdge = 0.75;
    else if (currentBet >= 5000) houseEdge = 0.70;

    let finalReels: string[];
    let res: 'win' | 'lose' | 'draw';
    let mult = 0;

    const rand = Math.random();
    if (rand > houseEdge) {
      // Win - all 3 same
      const sym = SYMBOLS[Math.floor(Math.random() * 5)];
      finalReels = [sym, sym, sym];
      res = 'win';
      if (sym === '🎰') mult = 7;
      else if (sym === '7️⃣') mult = 5;
      else if (sym === '💎') mult = 3;
      else if (sym === '⭐') mult = 2.5;
      else mult = 1.5;
    } else if (rand > houseEdge - 0.1) {
      // Draw - 2 same
      const sym = SYMBOLS[Math.floor(Math.random() * 5)];
      const other = weightedRandom();
      finalReels = [sym, sym, other];
      res = 'draw';
    } else {
      // Lose - all different
      let r: string[];
      do {
        r = [weightedRandom(), weightedRandom(), weightedRandom()];
      } while (r[0] === r[1] || r[1] === r[2]);
      finalReels = r;
      res = 'lose';
    }

    setReels(finalReels);
    setResult(res);

    const updatedUser = { ...user };
    let p = 0;

    if (res === 'win') {
      p = Math.floor(currentBet * mult) - currentBet;
      updatedUser.balance += p;
      updatedUser.totalWon += p + currentBet;
      setMultiplier(mult);
      addBigWin({ username: user.username, gameType: 'slot', amount: p + currentBet, date: new Date().toISOString() });
    } else if (res === 'draw') {
      const refund = Math.floor(currentBet * 0.3);
      p = refund - currentBet;
      updatedUser.balance += p;
      updatedUser.totalLost += Math.abs(p);
    } else {
      p = -currentBet;
      updatedUser.balance -= currentBet;
      updatedUser.totalLost += currentBet;
    }

    setProfit(p);
    updatedUser.gamesPlayed += 1;

    addGameSession(user.id, { gameType: 'slot', betAmount: currentBet, result: res, profitLoss: p, date: new Date().toISOString() });
    saveUser(updatedUser);
    onUserUpdate(updatedUser);
    setSpinning(false);
  }

  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-b from-purple-900 to-gray-900 text-white p-4">
      <div className="flex items-center gap-3 mb-6">
        <button onClick={onBack} className="text-gray-400 hover:text-white text-xl">←</button>
        <h1 className="text-xl font-bold">🎰 اسلات شانس</h1>
        <div className="mr-auto text-sm text-yellow-400 font-bold">💰 {user.balance.toLocaleString()}</div>
      </div>

      {/* Slot Machine */}
      <div className="bg-gradient-to-b from-purple-800 to-purple-900 rounded-3xl p-6 mb-6 border-2 border-purple-500 shadow-xl shadow-purple-900/50">
        <div className="flex justify-center gap-2 mb-4">
          {reels.map((r, i) => (
            <div key={i} className={`w-20 h-20 bg-gray-900 rounded-xl flex items-center justify-center text-4xl border-2 ${spinning ? 'border-yellow-400 animate-pulse' : 'border-gray-600'} shadow-inner`}>
              {r}
            </div>
          ))}
        </div>

        {result && (
          <div className={`text-center py-3 rounded-xl ${result === 'win' ? 'bg-green-800/50 text-green-300' : result === 'draw' ? 'bg-yellow-800/50 text-yellow-300' : 'bg-red-900/50 text-red-300'}`}>
            {result === 'win' && <div className="text-lg font-bold">🎉 بردید! x{multiplier}</div>}
            {result === 'draw' && <div className="text-lg font-bold">🤝 دو نماد یکسان! ۳۰٪ برگشت</div>}
            {result === 'lose' && <div className="text-lg font-bold">😔 باختید!</div>}
            <div className={`font-bold ${profit > 0 ? 'text-green-300' : profit < 0 ? 'text-red-300' : 'text-yellow-300'}`}>
              {profit > 0 ? '+' : ''}{profit.toLocaleString()} 🪙
            </div>
          </div>
        )}
      </div>

      {/* Prize Table */}
      <div className="bg-gray-800/50 rounded-xl p-3 mb-4 text-xs">
        <div className="text-center text-gray-400 mb-2">جدول جوایز</div>
        <div className="grid grid-cols-2 gap-1 text-gray-300">
          <div>🎰🎰🎰 = x7</div>
          <div>7️⃣7️⃣7️⃣ = x5</div>
          <div>💎💎💎 = x3</div>
          <div>⭐⭐⭐ = x2.5</div>
          <div>🍒/🍋/🍊 x3 = x1.5</div>
          <div>دو یکسان = 30%</div>
        </div>
      </div>

      {/* Bet Selection */}
      <div className="mb-4">
        <div className="text-gray-300 text-sm mb-2">انتخاب شرط:</div>
        <div className="grid grid-cols-3 gap-2 mb-2">
          {BETS.map(b => (
            <button
              key={b}
              onClick={() => { setBet(b); setCustomBet(''); }}
              className={`py-2 rounded-xl text-sm font-bold ${bet === b && !customBet ? 'bg-purple-500 text-white' : 'bg-gray-700 text-white hover:bg-gray-600'}`}
            >
              {b.toLocaleString()}
            </button>
          ))}
        </div>
        <input
          type="number"
          placeholder="مبلغ دلخواه..."
          value={customBet}
          onChange={e => setCustomBet(e.target.value)}
          className="w-full bg-gray-700 rounded-xl px-4 py-2 text-white text-center placeholder-gray-500 focus:outline-none"
        />
      </div>

      <button
        onClick={spin}
        disabled={spinning || currentBet < MIN_BET || currentBet > user.balance}
        className={`w-full py-4 rounded-2xl text-xl font-bold transition-all ${spinning || currentBet < MIN_BET || currentBet > user.balance
          ? 'bg-gray-600 text-gray-400 cursor-not-allowed'
          : 'bg-gradient-to-r from-purple-500 to-pink-500 text-white hover:opacity-90 active:scale-95 shadow-lg shadow-purple-900/50'}`}
      >
        {spinning ? '🎰 در حال چرخش...' : `🎰 چرخش! (${currentBet.toLocaleString()} 🪙)`}
      </button>

      {currentBet > user.balance && (
        <div className="mt-2 text-center text-red-400 text-sm">❌ موجودی کافی ندارید!</div>
      )}
    </div>
  );
}
