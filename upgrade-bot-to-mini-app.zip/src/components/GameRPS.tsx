import { useState } from 'react';
import { User } from '../types';
import { saveUser, addBigWin, addGameSession } from '../store';

interface Props {
  user: User;
  onUserUpdate: (u: User) => void;
  onBack: () => void;
}

const CHOICES = ['rock', 'paper', 'scissors'] as const;
type Choice = typeof CHOICES[number];

const EMOJI: Record<Choice, string> = { rock: '🪨', paper: '📄', scissors: '✂️' };
const FA: Record<Choice, string> = { rock: 'سنگ', paper: 'کاغذ', scissors: 'قیچی' };
const BEATS: Record<Choice, Choice> = { rock: 'paper', paper: 'scissors', scissors: 'rock' };
const LOSES_TO: Record<Choice, Choice> = { rock: 'scissors', paper: 'rock', scissors: 'paper' };

const BETS = [500, 1000, 5000, 10000, 50000, 100000];
const MIN_BET = 500;
const MULTIPLIER = 1.8;

export default function GameRPS({ user, onUserUpdate, onBack }: Props) {
  const [bet, setBet] = useState<number>(500);
  const [customBet, setCustomBet] = useState('');
  const [phase, setPhase] = useState<'bet' | 'play' | 'result'>('bet');
  const [playerChoice, setPlayerChoice] = useState<Choice | null>(null);
  const [botChoice, setBotChoice] = useState<Choice | null>(null);
  const [result, setResult] = useState<'win' | 'lose' | 'draw' | null>(null);
  const [profit, setProfit] = useState(0);
  const [animating, setAnimating] = useState(false);

  const currentBet = customBet ? parseInt(customBet.replace(/,/g, '')) || 0 : bet;

  function playGame(choice: Choice) {
    if (animating) return;
    if (currentBet < MIN_BET || currentBet > user.balance) return;

    setAnimating(true);
    setPlayerChoice(choice);
    setPhase('play');

    setTimeout(() => {
      // House edge logic
      let houseEdge = 0.50;
      if (currentBet >= 50000) houseEdge = 0.75;
      else if (currentBet >= 20000) houseEdge = 0.70;
      else if (currentBet >= 10000) houseEdge = 0.65;
      else if (currentBet >= 5000) houseEdge = 0.58;

      const rand = Math.random();
      let bc: Choice;
      let res: 'win' | 'lose' | 'draw';

      if (rand < houseEdge) {
        bc = BEATS[choice];
        res = 'lose';
      } else if (rand < houseEdge + 0.05) {
        bc = choice;
        res = 'draw';
      } else {
        bc = LOSES_TO[choice];
        res = 'win';
      }

      setBotChoice(bc);
      setResult(res);
      setPhase('result');

      const updatedUser = { ...user };
      if (res === 'win') {
        const gain = Math.floor(currentBet * MULTIPLIER) - currentBet;
        updatedUser.balance += gain;
        updatedUser.totalWon += gain + currentBet;
        setProfit(gain);
        addBigWin({ username: user.username, gameType: 'rps', amount: gain + currentBet, date: new Date().toISOString() });
      } else if (res === 'lose') {
        updatedUser.balance -= currentBet;
        updatedUser.totalLost += currentBet;
        setProfit(-currentBet);
      } else {
        setProfit(0);
      }
      updatedUser.gamesPlayed += 1;

      addGameSession(user.id, { gameType: 'rps', betAmount: currentBet, result: res, profitLoss: profit, date: new Date().toISOString() });
      saveUser(updatedUser);
      onUserUpdate(updatedUser);
      setAnimating(false);
    }, 1000);
  }

  function playAgain() {
    setPhase('bet');
    setPlayerChoice(null);
    setBotChoice(null);
    setResult(null);
    setProfit(0);
  }

  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-b from-gray-900 to-gray-800 text-white p-4">
      <div className="flex items-center gap-3 mb-6">
        <button onClick={onBack} className="text-gray-400 hover:text-white text-xl">←</button>
        <h1 className="text-xl font-bold">✂️ سنگ کاغذ قیچی</h1>
        <div className="mr-auto text-sm text-yellow-400 font-bold">💰 {user.balance.toLocaleString()}</div>
      </div>

      <div className="bg-gray-800 rounded-2xl p-4 mb-4 text-center">
        <div className="text-gray-400 text-sm mb-1">ضریب برد</div>
        <div className="text-green-400 text-2xl font-bold">{MULTIPLIER}x</div>
      </div>

      {phase === 'bet' && (
        <>
          <div className="mb-4">
            <div className="text-gray-300 text-sm mb-2">انتخاب شرط:</div>
            <div className="grid grid-cols-3 gap-2 mb-3">
              {BETS.map(b => (
                <button
                  key={b}
                  onClick={() => { setBet(b); setCustomBet(''); }}
                  className={`py-2 rounded-xl text-sm font-bold transition-all ${bet === b && !customBet ? 'bg-yellow-500 text-black' : 'bg-gray-700 text-white hover:bg-gray-600'}`}
                >
                  {b.toLocaleString()}
                </button>
              ))}
            </div>
            <input
              type="number"
              placeholder="مبلغ دلخواه..."
              value={customBet}
              onChange={e => setCustomBet(e.target.value)}
              className="w-full bg-gray-700 rounded-xl px-4 py-2 text-white text-center placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-yellow-500"
            />
          </div>

          <div className="text-center text-sm text-gray-400 mb-4">
            شرط: <span className="text-yellow-400 font-bold">{currentBet.toLocaleString()} 🪙</span>
            {currentBet > 0 && <span className="mr-2 text-green-400">| برد احتمالی: {Math.floor(currentBet * MULTIPLIER).toLocaleString()}</span>}
          </div>

          <div className="text-center text-gray-300 mb-4 font-bold">انتخاب کنید:</div>
          <div className="grid grid-cols-3 gap-3">
            {CHOICES.map(c => (
              <button
                key={c}
                onClick={() => playGame(c)}
                disabled={currentBet < MIN_BET || currentBet > user.balance}
                className="bg-gradient-to-b from-gray-700 to-gray-800 border-2 border-gray-600 rounded-2xl py-6 flex flex-col items-center gap-2 text-3xl hover:border-yellow-500 active:scale-95 transition-all disabled:opacity-40"
              >
                <span>{EMOJI[c]}</span>
                <span className="text-xs text-gray-300">{FA[c]}</span>
              </button>
            ))}
          </div>

          {currentBet > user.balance && (
            <div className="mt-4 text-center text-red-400 text-sm">❌ موجودی کافی ندارید!</div>
          )}
        </>
      )}

      {phase === 'play' && (
        <div className="flex-1 flex flex-col items-center justify-center gap-6">
          <div className="text-6xl animate-bounce">{playerChoice ? EMOJI[playerChoice] : '?'}</div>
          <div className="text-gray-400 text-lg">در حال بازی...</div>
          <div className="flex gap-3">
            {[1, 2, 3].map(i => (
              <div key={i} className={`w-3 h-3 rounded-full bg-yellow-500 animate-bounce`} style={{ animationDelay: `${i * 0.1}s` }} />
            ))}
          </div>
        </div>
      )}

      {phase === 'result' && playerChoice && botChoice && result && (
        <div className="flex-1 flex flex-col items-center justify-center gap-6">
          <div className="flex items-center gap-8">
            <div className="text-center">
              <div className="text-5xl mb-2">{EMOJI[playerChoice]}</div>
              <div className="text-sm text-gray-400">شما</div>
              <div className="text-xs text-gray-300">{FA[playerChoice]}</div>
            </div>
            <div className="text-2xl text-gray-500">VS</div>
            <div className="text-center">
              <div className="text-5xl mb-2">{EMOJI[botChoice]}</div>
              <div className="text-sm text-gray-400">ربات</div>
              <div className="text-xs text-gray-300">{FA[botChoice]}</div>
            </div>
          </div>

          <div className={`text-center p-6 rounded-2xl ${result === 'win' ? 'bg-green-900/50 border border-green-500' : result === 'lose' ? 'bg-red-900/50 border border-red-500' : 'bg-gray-700 border border-gray-500'}`}>
            <div className="text-4xl mb-2">{result === 'win' ? '🎉' : result === 'lose' ? '😔' : '🤝'}</div>
            <div className={`text-2xl font-bold ${result === 'win' ? 'text-green-400' : result === 'lose' ? 'text-red-400' : 'text-gray-300'}`}>
              {result === 'win' ? 'بردید!' : result === 'lose' ? 'باختید!' : 'مساوی!'}
            </div>
            <div className={`text-lg font-bold mt-2 ${profit > 0 ? 'text-green-300' : profit < 0 ? 'text-red-300' : 'text-gray-300'}`}>
              {profit > 0 ? '+' : ''}{profit.toLocaleString()} 🪙
            </div>
          </div>

          <div className="text-sm text-gray-400">موجودی: <span className="text-yellow-400 font-bold">{user.balance.toLocaleString()} 🪙</span></div>

          <div className="flex gap-3 w-full">
            <button onClick={playAgain} className="flex-1 bg-yellow-500 text-black font-bold py-3 rounded-xl">🔄 بازی مجدد</button>
            <button onClick={onBack} className="flex-1 bg-gray-700 text-white py-3 rounded-xl">🎮 بازی‌ها</button>
          </div>
        </div>
      )}
    </div>
  );
}
