import { useState } from 'react';
import { User } from '../types';
import { saveUser, addBigWin, addGameSession } from '../store';

interface Props {
  user: User;
  onUserUpdate: (u: User) => void;
  onBack: () => void;
}

const BETS = [2000, 5000, 10000, 20000, 50000];
const MIN_BET = 2000;
const MULTIPLIER = 2.8;

export default function GameGuess({ user, onUserUpdate, onBack }: Props) {
  const [bet, setBet] = useState(2000);
  const [customBet, setCustomBet] = useState('');
  const [phase, setPhase] = useState<'bet' | 'guess' | 'result'>('bet');
  const [secret, setSecret] = useState(0);
  const [guess, setGuess] = useState<number | null>(null);
  const [result, setResult] = useState<'win' | 'lose' | null>(null);
  const [profit, setProfit] = useState(0);

  const currentBet = customBet ? parseInt(customBet) || 0 : bet;

  function startGuess() {
    if (currentBet < MIN_BET || currentBet > user.balance) return;
    const n = Math.floor(Math.random() * 10) + 1;
    setSecret(n);
    setPhase('guess');
  }

  function submitGuess(g: number) {
    let actualSecret = secret;
    // House edge for high bets
    if (currentBet >= 20000 && Math.random() < 0.80) {
      while (actualSecret === g) actualSecret = Math.floor(Math.random() * 10) + 1;
    } else if (currentBet >= 10000 && Math.random() < 0.65) {
      while (actualSecret === g) actualSecret = Math.floor(Math.random() * 10) + 1;
    }

    setGuess(g);
    const won = g === actualSecret;
    setResult(won ? 'win' : 'lose');
    setPhase('result');
    setSecret(actualSecret);

    const updatedUser = { ...user };
    let p = 0;
    if (won) {
      p = Math.floor(currentBet * MULTIPLIER) - currentBet;
      updatedUser.balance += p;
      updatedUser.totalWon += p + currentBet;
      addBigWin({ username: user.username, gameType: 'guess', amount: p + currentBet, date: new Date().toISOString() });
    } else {
      p = -currentBet;
      updatedUser.balance -= currentBet;
      updatedUser.totalLost += currentBet;
    }
    setProfit(p);
    updatedUser.gamesPlayed += 1;
    addGameSession(user.id, { gameType: 'guess', betAmount: currentBet, result: won ? 'win' : 'lose', profitLoss: p, date: new Date().toISOString() });
    saveUser(updatedUser);
    onUserUpdate(updatedUser);
  }

  function playAgain() {
    setPhase('bet');
    setGuess(null);
    setResult(null);
    setProfit(0);
  }

  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-b from-blue-900 to-gray-900 text-white p-4">
      <div className="flex items-center gap-3 mb-6">
        <button onClick={onBack} className="text-gray-400 hover:text-white text-xl">←</button>
        <h1 className="text-xl font-bold">🎯 حدس عدد</h1>
        <div className="mr-auto text-sm text-yellow-400 font-bold">💰 {user.balance.toLocaleString()}</div>
      </div>

      <div className="bg-blue-800/40 rounded-2xl p-4 mb-6 text-center border border-blue-700">
        <div className="text-gray-400 text-sm mb-1">ضریب برد</div>
        <div className="text-green-400 text-3xl font-bold">{MULTIPLIER}x</div>
        <div className="text-gray-400 text-sm mt-1">عدد بین ۱ تا ۱۰</div>
      </div>

      {phase === 'bet' && (
        <>
          <div className="mb-4">
            <div className="text-gray-300 text-sm mb-2">انتخاب شرط:</div>
            <div className="grid grid-cols-3 gap-2 mb-2">
              {BETS.map(b => (
                <button key={b} onClick={() => { setBet(b); setCustomBet(''); }}
                  className={`py-2 rounded-xl text-sm font-bold ${bet === b && !customBet ? 'bg-blue-500 text-white' : 'bg-gray-700 text-white hover:bg-gray-600'}`}>
                  {b.toLocaleString()}
                </button>
              ))}
            </div>
            <input type="number" placeholder="مبلغ دلخواه..." value={customBet}
              onChange={e => setCustomBet(e.target.value)}
              className="w-full bg-gray-700 rounded-xl px-4 py-2 text-white text-center placeholder-gray-500 focus:outline-none" />
          </div>

          <div className="text-center text-sm text-gray-400 mb-4">
            برد احتمالی: <span className="text-green-400 font-bold">{Math.floor(currentBet * MULTIPLIER).toLocaleString()} 🪙</span>
          </div>

          <button onClick={startGuess} disabled={currentBet < MIN_BET || currentBet > user.balance}
            className={`w-full py-4 rounded-2xl text-lg font-bold ${currentBet >= MIN_BET && currentBet <= user.balance
              ? 'bg-blue-500 text-white hover:bg-blue-400 active:scale-95'
              : 'bg-gray-600 text-gray-400 cursor-not-allowed'}`}>
            🎯 شروع بازی ({currentBet.toLocaleString()} 🪙)
          </button>
        </>
      )}

      {phase === 'guess' && (
        <div className="flex-1">
          <div className="text-center text-xl font-bold mb-6 text-blue-300">عدد مورد نظر را انتخاب کنید:</div>
          <div className="text-center text-sm text-gray-400 mb-6">شرط: {currentBet.toLocaleString()} 🪙 | برد: {Math.floor(currentBet * MULTIPLIER).toLocaleString()} 🪙</div>
          <div className="grid grid-cols-5 gap-3">
            {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(n => (
              <button key={n} onClick={() => submitGuess(n)}
                className="aspect-square bg-blue-800/50 hover:bg-blue-600 active:scale-95 rounded-2xl text-2xl font-bold border-2 border-blue-700 hover:border-blue-400 transition-all">
                {n}
              </button>
            ))}
          </div>
        </div>
      )}

      {phase === 'result' && (
        <div className="flex-1 flex flex-col items-center justify-center gap-6">
          <div className={`text-center p-8 rounded-3xl w-full ${result === 'win' ? 'bg-green-900/50 border-2 border-green-500' : 'bg-red-900/50 border-2 border-red-500'}`}>
            <div className="text-6xl mb-4">{result === 'win' ? '🎯' : '❌'}</div>
            <div className="text-2xl font-bold mb-2">{result === 'win' ? '🎉 درست حدس زدید!' : '😔 اشتباه!'}</div>
            <div className="text-lg text-gray-300">عدد: <span className="text-white font-bold text-2xl">{secret}</span></div>
            {guess && <div className="text-sm text-gray-400">حدس شما: {guess}</div>}
            <div className={`text-2xl font-bold mt-3 ${profit > 0 ? 'text-green-300' : 'text-red-300'}`}>
              {profit > 0 ? '+' : ''}{profit.toLocaleString()} 🪙
            </div>
          </div>

          <div className="text-gray-400 text-sm">موجودی: <span className="text-yellow-400 font-bold">{user.balance.toLocaleString()}</span></div>

          <div className="flex gap-3 w-full">
            <button onClick={playAgain} className="flex-1 bg-blue-500 text-white font-bold py-3 rounded-xl">🔄 بازی مجدد</button>
            <button onClick={onBack} className="flex-1 bg-gray-700 text-white py-3 rounded-xl">🎮 بازی‌ها</button>
          </div>
        </div>
      )}
    </div>
  );
}
